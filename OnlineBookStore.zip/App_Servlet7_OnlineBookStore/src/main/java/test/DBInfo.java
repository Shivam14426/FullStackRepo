package test;
public interface DBInfo {
public static final String dbUrl="jdbc:oracle:thin:@localhost:1521:orcl";
public static final String uName="System";
public static final String pWord="skdb";
}
